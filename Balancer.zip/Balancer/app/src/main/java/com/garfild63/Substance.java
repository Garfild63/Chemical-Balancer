package com.garfild63;

import java.util.Enumeration;
import java.util.Hashtable;

public class Substance {
  private final Hashtable els;
  private String name = null;
  
  public Substance() {
    els = new Hashtable();
  }
  
  public Substance(String name) {
    this();
    this.name = name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public Substance addElement(String el, int k) {
    if (els.containsKey(el)) {
      int n = ((Integer) els.get(el)).intValue();
      n += k;
      els.put(el, new Integer(n));
    } else {
      els.put(el, new Integer(k));
    }
    return this;
  }
  
  public Substance add(Substance s) {
    Enumeration e = s.els.keys();
    while (e.hasMoreElements()) {
      String el = (String) e.nextElement();
      int i = ((Integer) s.els.get(el)).intValue();
      addElement(el, i);
    }
    return this;
  }
  
  public Substance multiple(int n) {
    Enumeration e = els.keys();
    while (e.hasMoreElements()) {
      String el = (String) e.nextElement();
      int i = ((Integer) els.get(el)).intValue();
      els.put(el, new Integer(i * n));
    }
    return this;
  }
  
  public String toString() {
    if (name != null)
      return name;
    Enumeration e = els.keys();
    StringBuffer sb = new StringBuffer();
    while (e.hasMoreElements()) {
      String el = (String) e.nextElement();
      int i = ((Integer) els.get(el)).intValue();
      sb.append(el + i);
    }
    return sb.toString();
  }
}
